NES Sort by Shiru

This simple tool is designed to do a very specific job. It takes a directory with uncompressed NES ROM files (*.nes) and sorts the files by mapper number, moving them into newly created sub directories. This could be useful for emulator testing purposes, when you need to select a number of games that use certain mapper(s).

Be careful! The program will move files from the original directory after you press 'Run' button!


v1.0 03.03.13 - Initial release

Mail:	shiru@mail.ru
Web:    http:// shiru.untergrund.net
Donate: http://www.justgiving.com/Shiru