//---------------------------------------------------------------------------

#include <vcl.h>
#include <dir.h>
#include <stdlib.h>
#include <stdio.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	struct ffblk f;
	FILE *file;
	AnsiString RootDir;
	TListItem  *item;
	int done,mapper,chr,prg;
	unsigned char header[16];

	RootDir=ParamStr(0);

	if(SelectDirectory("Select directory:","",RootDir))
	{
		EditDir->Text=RootDir;

		ListViewFiles->Clear();

		done=findfirst((EditDir->Text+"\\*.nes").c_str(),&f,0);

		while(!done)
		{
			file=fopen((RootDir+"\\"+f.ff_name).c_str(),"rb");

			if(file)
			{
				fread(header,16,1,file);
				fclose(file);

				item=ListViewFiles->Items->Add();
				item->Caption=AnsiString(f.ff_name);

				if(!memcmp(header,"NES",3))
				{
					prg=header[4];
					chr=header[5];
					mapper=((header[6]>>4)&0x0f)|(header[7]&0xf0);

					item->SubItems->Add(IntToStr(mapper));
					item->SubItems->Add(IntToStr(prg*16)+"K");
					if(chr) item->SubItems->Add(IntToStr(chr*8)+"K"); else item->SubItems->Add("RAM");
				}
				else
				{
					item->SubItems->Add("???");
					item->SubItems->Add("???");
					item->SubItems->Add("???");
				}
			}

			done=findnext(&f);
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
	AnsiString srcpath,dstpath,dstdir;
	int i;

	for(i=0;i<ListViewFiles->Items->Count;++i)
	{
		srcpath=EditDir->Text+"\\"+ListViewFiles->Items->Item[i]->Caption;

		if(ListViewFiles->Items->Item[i]->SubItems->Strings[0]!="???")
		{
			dstdir=EditDir->Text+"\\"+ListViewFiles->Items->Item[i]->SubItems->Strings[0];
		}
		else
		{
			dstdir=EditDir->Text+"\\unknown";
		}
		
		dstpath=dstdir+"\\"+ListViewFiles->Items->Item[i]->Caption;

		CreateDirectory(dstdir.c_str(),NULL);
		MoveFile(srcpath.c_str(),dstpath.c_str());
	}

	ListViewFiles->Clear();
}
//---------------------------------------------------------------------------

